export default [
  {
    title: "Need to Return an Item?",
    description: "get the item you ordered or your money back- it's simple",
    link: "#",
    linktext: "Learn More",
  },
  {
    title: "Get the Best from the East",
    description: "From La to Lisbon to London, Shop the best of the East",
    link: "#",
    linktext: "Go East",
  },
  {
    title: "Around the Corner, Across the Globe",
    description: "Wherever it is, you can find it on ebay",
    link: "#",
    linktext: "Drive in",
    image: "url",
  },
];
