import React, { useEffect, useState } from 'react';
import { Table, Button, Tag } from 'antd';
import { Link } from 'react-router-dom';

const AccountManagement = () => {
  const [accounts, setAccounts] = useState([]);  // State lưu trữ danh sách tài khoản
  const [loading, setLoading] = useState(true);   // State kiểm tra trạng thái loading

  // Hàm lấy danh sách người dùng và role từ API
  useEffect(() => {
    const fetchAccounts = async () => {
      try {
        // Lấy danh sách người dùng
        const usersResponse = await fetch('http://localhost:9999/users');
        const usersData = await usersResponse.json();

        // Lấy danh sách các vai trò
        const rolesResponse = await fetch('http://localhost:9999/roles');
        const rolesData = await rolesResponse.json();

        // Lấy mối quan hệ giữa người dùng và vai trò
        const userRolesResponse = await fetch('http://localhost:9999/user_roles');
        const userRolesData = await userRolesResponse.json();

        // Ghép thông tin role vào mỗi tài khoản
        const updatedAccounts = usersData.map(user => {
          // Lấy các user_roles cho người dùng
          const userRoles = userRolesData.filter(userRole => userRole.user_id == user.id);
          console.log("userRoles:" + userRoles);
          // Lấy các role_id của người dùng
          const userRoleIds = userRoles.map(userRole => userRole.role_id);
          console.log("userRoleIds:" + userRoleIds);
          // Lấy tên role từ bảng roles
          const userRolesNames = rolesData.filter(role => userRoleIds.includes(role.id))
            .map(role => role.name);  // Ghép tên role từ bảng roles

          // In ra thông tin user và roles để debug
          console.log(`User: ${user.name}, Roles: ${userRolesNames}`);

          return {
            ...user,
            roles: userRolesNames,  // Lưu thông tin các role của người dùng
          };
        });

        setAccounts(updatedAccounts);  // Lưu danh sách tài khoản và role vào state
      } catch (error) {
        console.error('Error fetching accounts:', error);
      } finally {
        setLoading(false);  // Đánh dấu kết thúc loading
      }
    };

    fetchAccounts();
  }, []);

  // Cấu hình các cột trong bảng
  const columns = [
    {
      title: 'ID',
      dataIndex: 'id', // Trường id trong API
      key: 'id',
      align: 'center',  // Căn giữa cột
    },
    {
      title: 'Name',
      dataIndex: 'name', // Trường name trong API
      key: 'name',
      align: 'center',  // Căn giữa cột
    },
    {
      title: 'Email',
      dataIndex: 'email', // Trường email trong API
      key: 'email',
      align: 'center',  // Căn giữa cột
    },
    {
      title: 'Role',
      dataIndex: 'roles',  // Trường roles trong API
      key: 'roles',
      align: 'center',  // Căn giữa cột
      render: (roles) => (
        roles && roles.length > 0 ? (
          roles.map(role => <Tag color="blue" key={role}>{role}</Tag>)
        ) : 'No roles'
      ),
    },
    {
      title: 'Action',
      key: 'action',
      align: 'center',  // Căn giữa cột
      render: (text, record) => (
        <Button type="primary">
          <Link to={`/account/${record.id}`}>View Detail</Link>  {/* Chuyển hướng đến trang chi tiết của tài khoản */}
        </Button>
      ),
    },
  ];

  return (
    <div style={{ padding: '20px' }}>
      <h1 style={{ textAlign: 'center', marginBottom: '20px' }}>Account Management</h1>
      <Table
        columns={columns}
        dataSource={accounts}
        loading={loading}
        rowKey="id" // Chỉ định trường key cho mỗi dòng trong bảng
        bordered={true}  // Thêm viền cho bảng
        pagination={{ pageSize: 5 }}  // Pagination (hiển thị 5 dòng mỗi trang)
      />
    </div>
  );
};

export default AccountManagement;
