import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';  // Để lấy tham số URL
import { Card, Spin } from 'antd';

const AccountDetail = () => {
  const { id } = useParams();  // Lấy tham số ID từ URL
  const [account, setAccount] = useState(null);  // Lưu thông tin tài khoản
  const [loading, setLoading] = useState(true);  // Trạng thái loading

  useEffect(() => {
    const fetchAccountDetail = async () => {
      try {
        const response = await fetch(`http://localhost:9999/users/${id}`);  // API lấy thông tin chi tiết tài khoản
        const data = await response.json();
        setAccount(data);
      } catch (error) {
        console.error('Error fetching account detail:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchAccountDetail();
  }, [id]);  // Chạy lại khi ID thay đổi

  if (loading) {
    return <Spin size="large" />;  // Hiển thị loading khi dữ liệu chưa được tải
  }

  return (
    <div>
      <h1>Account Detail</h1>
      {account && (
        <Card title={`Account: ${account.name}`}>
          <p><strong>ID:</strong> {account.id}</p>
          <p><strong>Name:</strong> {account.name}</p>
          <p><strong>Email:</strong> {account.email}</p>
          <p><strong>Address:</strong> {account.address}</p> {/* Thêm các thông tin chi tiết nếu có */}
        </Card>
      )}
    </div>
  );
};

export default AccountDetail;
