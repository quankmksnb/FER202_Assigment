export default [
  {
    color: "red",
    title: "I am A boy",
    desc: "whereever it is you can find it on ebay",
    button: "buy it",
    imgUrl:
      "https://images.unsplash.com/photo-1600611119326-99e8096d3470?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1525&q=80",
  },
  {
    color: "blue",
    title: "I am A G",
    desc: "wI am A boyI am A boyhereever it is you can find it on ebay",
    button: "buy it",
    imgUrl:
      "https://images.unsplash.com/photo-1465310477141-6fb93167a273?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=750&q=80",
  },
  {
    color: "green",
    title: "I am A boy",
    desc: "wherI am A boyI am A boyeever it is you can find it on ebay",
    button: "buy it",
    imgUrl:
      "https://images.unsplash.com/photo-1485217988980-11786ced9454?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=750&q=80",
  },
  {
    color: "pink",
    title: "I am A boy",
    desc: "whereever it is you can find it on ebay",
    button: "buy it",
    imgUrl:
      "https://images.unsplash.com/photo-1488415032361-b7e238421f1b?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=749&q=80",
  },
];
